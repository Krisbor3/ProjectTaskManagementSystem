package Models;

import Enums.TYPE_WORKER;
import Models.Users.User;

import java.util.List;

public class StatBoard {
    private TYPE_WORKER typeWorker;
    private int completedTasks;
    private List<User> users;

    public StatBoard(TYPE_WORKER typeWorker, int completedTasks, List<User> users) {
        this.typeWorker = typeWorker;
        this.completedTasks = completedTasks;
        this.users = users;
    }

    public TYPE_WORKER getTypeWorker() {
        return typeWorker;
    }

    public void setTypeWorker(TYPE_WORKER typeWorker) {
        this.typeWorker = typeWorker;
    }

    public int getCompletedTasks() {
        return completedTasks;
    }

    public void setCompletedTasks(int completedTasks) {
        this.completedTasks = completedTasks;
    }
}
