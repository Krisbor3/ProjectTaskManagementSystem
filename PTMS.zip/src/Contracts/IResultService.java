package Contracts;

import Models.Result;

public interface IResultService extends IService<Result> {
}
