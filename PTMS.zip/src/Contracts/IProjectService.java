package Contracts;

import Models.Project;

public interface IProjectService extends IService<Project>{
}
