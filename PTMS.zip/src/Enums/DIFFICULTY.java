package Enums;

public enum DIFFICULTY {
    EASY,MEDIUM,HARD
}
