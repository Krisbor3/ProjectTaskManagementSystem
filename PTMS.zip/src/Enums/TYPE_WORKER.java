package Enums;

public enum TYPE_WORKER {
    SENIOR,STUDENT
}
