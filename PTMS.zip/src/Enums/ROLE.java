package Enums;

public enum ROLE {
ADMINISTRATOR,SENIOR,STUDENT,NOT_SET
}
