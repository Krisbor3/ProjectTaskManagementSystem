INSERT INTO `ptms`.`users` (`id`, `firstname`, `lastname`, `email`, `username`, `password`)
VALUES ('1', 'John', 'Doe', 'john@gmail.com', 'jhonathan', 'jj123@');

INSERT INTO `ptms`.`tasks` (`name`, `difficulty`) VALUES ('User Interface', 'EASY');

