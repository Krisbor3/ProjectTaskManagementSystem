package Implementations;

public class JDBCConstants {
    public final static String Url ="jdbc:mysql://localhost:3306/ptms";

    public final static String User = "root";

    public final static String Password = "root";
}
