package Infrastructure;

import Models.Users.User;

public interface UserRepository extends Repository<Long, User>{
}
