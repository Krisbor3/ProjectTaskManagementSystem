package Infrastructure;

import Models.Project;

public interface ProjectRepository extends Repository<Long, Project>{
}
