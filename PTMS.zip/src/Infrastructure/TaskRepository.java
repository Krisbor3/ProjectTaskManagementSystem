package Infrastructure;

import Models.Task;

public interface TaskRepository extends Repository<Long, Task>{
}
