package Infrastructure;

import Models.Result;

public interface ResultRepository extends Repository<Long, Result> {
}
